package uninter;

public abstract class Moeda {
//Criei uma classe para converter moedas	
	double valor;
	
	public abstract void info();
	public abstract double converter();
	
}
